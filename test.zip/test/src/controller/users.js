const mysql = require("mysql2");
const jwt = require("jsonwebtoken");

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "login",
});

// var token = jwt.sign({ foo: "bar" }, "shhhhh");

const login = (req, res) => {
  const { username, password } = req.body;

  const nickname =
    "SELECT nickname,id_user FROM user WHERE password = ? AND username = ?";
  db.execute(nickname, [password, username], (err, result) => {
    if (err) {
      console.error("GAGAL MENGAMBIL NICKNAME", err);
      res.status(500).json({
        message: "GAGAL MENGAMBIL NICKNAME",
        error: err,
      });
    } else {
      if (result.length > 0) {
        const sessionObject = {
          nama: username,
          tanggal: new Date(),
        };
        const key = "mirorim";
        const token = jwt.sign(sessionObject, key);
        console.log(sessionObject);
        console.log(token);
        // select id_user in session
        const selectIdUser =
          "SELECT id_user FROM session WHERE id_user = ? AND logout = 0";
        db.execute(selectIdUser, [result[0].id_user], (errorlog, resultlog) => {
          if (errorlog) {
            res.status(500).json({
              message: "gagal mendapatkan id_user",
              error: errorlog,
            });
          } else{
            if (resultlog.length > 0) {
              res.json({
                errorCode: "00",
                message: "sudah login",
                token: token,
              });
            } else {
              const queryInsert =
                "INSERT INTO session(id_user,token,logout) VALUES(?,?,?)";
              db.execute(
                queryInsert,
                [result[0].id_user, token, false],
                (error, rslt) => {
                  if (error) {
                    res.status(500).json({
                      message: "gagal memasukan token",
                      error: error,
                    });
                  } else {
                    res.json({
                      errorCode: "00",
                      message: "Berhasil login",
                      token: token,
                    });
                  }
                }
              );
              console.log("Ada data yang terambil");
            }
          } 
          
        });
      } else {
        res.json({
          errorCode: "55",
          message: "Tidak ada data pengguna yang ditemukan",
          token: null,
        });
      }
    }
  });
};

module.exports = {
  login,
};
