const express = require('express');
const routes = express();
const userController = require('../controller/users');

//Get atau Selet
//Create - POST
routes.post("/", userController.login);



module.exports = routes;